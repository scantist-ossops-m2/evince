#ifndef MDVI_FONTS_REGISTRATION_H
#define MDVI_FONTS_REGISTRATION_H

void mdvi_register_fonts (void);

#endif /* MDVI_FONTS_REGISTRATION_H */
